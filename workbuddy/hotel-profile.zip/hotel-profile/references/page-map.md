# 页面结构参考（2026-11-15 实测）

> 平台会改版。以下类名来自真实登录态实测，不是稳定契约。改版后先跑 `--calibrate <url>`，看 `output/calibration.json` 的 `class_hints` 再调 `config/selectors.json`。

## URL

| 用途 | 模板 |
| --- | --- |
| 城市列表页 | `https://hotels.ctrip.com/hotels/list?city={city_id}&checkin={checkin}&checkout={checkout}` |
| 详情页 | `https://hotels.ctrip.com/hotels/detail/?hotelId={hotel_id}&checkin={checkin}&checkout={checkout}` |

日期分隔符是 `/`。实测 `city=2` → 上海。hotel_id 来自列表页 `.hotel-card` 的 `id` 属性。

## 列表页

| 字段 | 选择器 |
| --- | --- |
| 卡片容器 | `.hotel-card` |
| 酒店名 | `[class*=hotelName]` |
| 评分 / 点评数 | `.comment-score` / `.comment-num` |
| 位置 | `.hotel-position` |
| 价格块 | `.room-price` |

**价格块内部**（这是取价关键）：

| 选择器 | 含义 | 例 |
| --- | --- | --- |
| `.promotion-tag` | 会员价标签 | 会员价 |
| `.discount-tag` | 优惠金额，**不是价格** | 优惠174 |
| `.delete.delete-tilt` | 划线原价 | ¥1,154 |
| `.sale` | **成交价，要取这个** | ¥980 |
| `.price-suffix` | 后缀 | 起 |

**禁用** `[class*=price]`：会命中左侧筛选栏（`¥0 - ¥200`）。

## 详情页

| 字段 | 选择器 |
| --- | --- |
| 酒店名 / 地址 / 电话 | `[class*=hotelNameRow_hotelOverview_name]` / `[class*=hotelAddre]` / `[class*=hotelContact]` |
| 房型卡片 / 房型名 | `[class*=commonRoomCard__]` / `[class*=commonRoomCard-title]` |
| 服务及设施 | `[class*=hotelFacilityNew_hotelFacilityNewA]` |
| 设施条目 | `[class*=hotelFacility-popular_item]` |
| 地点/周边 | `[class*=hotelLocationNew]`，正文「附近 … 在地图上查看」 |
| 地铁 | `[class*=hotelLocation-detail]` |
| 酒店政策 | `[class*=hotelPolicyNew_hotelPolicyNew]` |
| 评分/点评 | `[class*=reviewScore]`（**评分要从正文独立行抽，别取这里的数字**） |
