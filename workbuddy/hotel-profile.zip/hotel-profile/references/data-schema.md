# 字段口径

## 一、价格快照 ctrip_prices.csv

一行 = 一次快照（一个酒店卡片）。

| 列 | 含义 | 口径 |
| --- | --- | --- |
| `capture_time` | 抓取时刻 | 本机时间 YYYY-MM-DD HH:MM:SS |
| `hotel_name` | 酒店名 | 页面渲染文本 |
| `rating` / `rating_num` | 评分 | 原文 / 抽出的浮点（如 4.9） |
| `review_count` / `review_num` | 点评数 | 原文 / 抽出的整数 |
| `address` | 位置 | 如「近地铁站 · 商圈」 |
| `ctrip_price` | **成交价** | 取 `.room-price .sale` 原文 |
| `list_price` | 划线原价 | 取 `.room-price .delete` |
| `price_num` | 可计算价格 | 从成交价抽**锚定 ¥ 的**整数；未登录/无价为 null |
| `promo_tags` | 促销标签 | 如「免费取消」「会员价」 |
| `status` | 状态 | `ok` / `partial` / `needs_login` / `blocked` / `failed` / `error` |

⚠️ 价格正则必须锚定 `¥`。不锚定会把「优惠174」「连续54位住客好评」里的数字当成价格。

## 二、酒店概览 ctrip_profiles.csv

| 列 | 含义 |
| --- | --- |
| `ctrip_hotel_id` / `hotel_name` / `city` / `address` / `phone` | 基本信息 |
| `rating` / `review_count` | 评分 / 点评数（从正文独立行抽，别取「N 条评论」里的 N） |
| `room_type_count` | 房型数 = `ctrip_rooms.csv` 中该酒店去重行数 |
| `facilities` | 服务及设施全文（最长 6000 字） |
| `has_meeting_room` `has_pool` `has_gym` `has_parking` `has_restaurant` `has_spa` `has_airport_shuttle` `has_wifi` `has_bar` | 设施标记。「是」= 设施全文出现对应关键词；「否」= 未出现。**只反映页面文本，不臆测** |
| `nearby_summary` / `nearby_poi_count` | 「类别:名称(距离)」串 / POI 数 |
| `metro` | 地铁站与距离 |
| `intro` / `highlights` | 简介 / 亮点标签 |
| `policy` / `breakfast_policy` | 入离时间等 / 早餐政策 |

## 三、房型 ctrip_rooms.csv

`room_name` 房型名｜`bed_type` 床型｜`area_sqm` 面积㎡｜`floor` 楼层｜`window` 有窗/无窗｜`smoke` 禁烟｜`wifi`｜`price_num` / `price_text` 房型起价｜`breakfast` 早餐｜`cancellation` 取消政策｜`availability` 余量。抽不到留空，不猜。

## 四、周边 ctrip_nearby.csv

`category` 类别（地铁站/地标/购物/休闲娱乐/火车站…）｜`poi_name` 名称｜`distance` 距离（如「1.2公里」「310米」）。

## 去重与历史

- `progress.json` / `progress_profile.json` 记录已完成 key（url 或 hotel_id + 入离日期 + 模式），重跑自动跳过
- CSV **追加**写，多次同日运行形成多条快照，用 `capture_time` 区分
