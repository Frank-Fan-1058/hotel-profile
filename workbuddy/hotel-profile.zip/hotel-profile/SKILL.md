---
name: hotel-profile
display_name: 酒店价格与全档案采集
display_name_en: Hotel Price & Profile Collector
description: 批量采集酒店的最新的价格、评分、点评数、房型、会议室/泳池/健身房等设施、周边配套与政策。当用户要查、比价、监控酒店价格，或要整理酒店设施与周边参数清单，或要给出一批酒店的价格与档案对比表时使用。触发词：酒店价格、酒店比价、酒店信息采集、酒店设施、周边配套、酒店档案、批量查酒店。
description_zh: 通过真实已登录的浏览器批量采集酒店价格与全档案（房型、设施、周边配套、政策、简介），输出 CSV / JSONL / Excel，可断点续跑。
description_en: Collect hotel prices and full profiles (rooms, facilities, nearby POIs, policies) at scale through a real logged-in browser. Outputs CSV / JSONL / Excel with resume support.
examples_zh:
- "帮我查这 5 家酒店 11 月 20 日的价格和房型"
- "把这些酒店的会议室、泳池、健身房情况整理成一张表"
- "每天早上 9 点跑一次这 20 家酒店的房价，看看有没有降价"
examples_en:
- "Get prices and room types for these 5 hotels on Nov 20"
- "Put meeting room, pool and gym availability for these hotels into one table"
- "Run a daily price check on these 20 hotels and flag any drops"
version: 1.0.0
author: "Frank-Fan-1058"
allowed-tools: Bash, Read, Write, Edit
---

# 酒店价格与全档案采集

## 何时使用

用户需要下列任一结果时使用本技能：

- 一批酒店的**最新价格**（成交价、划线原价、评分、点评数）
- 酒店的**全档案**：房型（床型/面积/楼层/窗/早餐/取消政策/余量）、设施（会议室、泳池、健身房、餐厅、停车场、SPA、接送机、WiFi、酒吧）、周边配套（地铁站、地标、购物、休闲娱乐及距离）、政策与简介
- 多家酒店的**价格与档案对比表 / Excel**

## 前置条件（缺一不可，缺了先告知用户）

1. **真实浏览器已登录目标平台**：本技能只读取用户自己浏览器里已登录的页面。未登录时平台只显示「登录以查看会员价」，价格为空白。
2. **browser-skill（`bsk`）CLI 可用**：`bsk` 在 PATH，或环境变量 `BSK_CLI` 指向可执行文件；浏览器扩展已连接（`BSK_AUTO_START=0 bsk status --json` 能看到 `browsers[].instance_id`）。
3. **Python 3.9+**：生成 Excel 需 `pip install openpyxl`（缺失时仍输出 CSV/JSONL）。

缺 2 或 3 时，把安装方法告诉用户并停下，不要假装能跑。

## 执行步骤

### 第 1 步：确认输入

问清（或用用户已给的信息）：

- 目标平台与城市：默认 ctrip.com；城市用 `city_id`（实测 `city=2` 是上海）
- 入住 / 离店日期
- 酒店清单：优先要 **hotel_id**（列表页卡片 `id` 属性）；拿不到 ID 就用列表页 URL 自动发现

把清单写入 `config/hotels.profile.csv`（全档案）或 `config/hotels.csv`（价格快照），列：
`hotel_id,url,city_id,city,hotel_name,checkin,checkout,room_type,note`

首次使用先复制模板：
```bash
cp config/hotels.profile.example.csv config/hotels.profile.csv
```

### 第 2 步：自检

```bash
python scripts/verify_probe.py
```

输出 `结果: OK` 才继续；报 `no_browser_connected` 说明扩展断线，请用户打开浏览器扩展等待重连；报 `bsk⟧ 找不到，回到前置条件 2。

### 第 3 步：跑采集

**只要价格**（列表页，一次抓整页）：
```bash
python scripts/ctrip_hotel.py --mode list --limit 1
```

**要全档案**（逐家详情页）：
```bash
python scripts/ctrip_hotel.py --mode profile --limit 10
```

**不知道 hotel_id**：让脚本先从列表页发现，再逐家抓：
```bash
python scripts/ctrip_hotel.py --mode profile --from-list "<列表页URL>" --limit 10
```

**无人值守 / 定时**：加 `--no-handoff`，遇登录墙或验证码只记 `needs_login` 不阻塞。

单次运行控制在 10–20 家以内；更多就分批，批间自然停顿。不要并发、不要缩短等待。

### 第 4 步：读结果并交付

输出在 `output/`：

| 文件 | 内容 |
| --- | --- |
| `ctrip_prices.csv / .jsonl / .xlsx` | 列表页价格快照，追加写 |
| `ctrip_profiles.csv` | 一家一行：基本信息 + 9 项设施标记 + 周边汇总 + 政策 + 简介 |
| `ctrip_rooms.csv` | 一个房型一行：床型/面积/楼层/窗/烟/WiFi/价/早餐/取消/余量 |
| `ctrip_nearby.csv` | 一个 POI 一行：类别/名称/距离 |
| `ctrip_hotel_full.xlsx` | 上面三张表各一个 sheet |

给用户的回复里：
- 先说结论（抓到几家、成功几家、价格区间），再给表
- 表格只放用户要的字段，不要加备注/建议列
- 明确说明：**设施标记是按页面文本判定的**，页面没写就记「否」，不代表酒店一定没有
- 有酒店失败时列出名字与原因（`needs_login` / `blocked` / `failed`），不要掩盖

## 硬性约束

**必须做**

- 复用用户真实已登录的浏览器；串行、单标签、随机停顿、滚动、停留、分批休息
- 只读页面**渲染后**的内容；增量写盘 + `progress*.json` 断点续跑
- 遇验证码 / 滑块 / 登录墙 → 停下交给用户处理，不硬闯

**禁止**

- 不 headless、不新开干净 profile、不改 UA、不导出 cookie
- 不重放页面内部 XHR / 内部 JSON 接口、不伪造签名、不逆向签名算法
- 不并发提速、不高频轮询、不绕过验证码
- 不编数据：没抓到就写 null / 「未找到」，不要填一个像样的数字

## 页面改版了怎么办

采集结果为 0 行或字段大量为空，多半是选择器变了：

```bash
python scripts/ctrip_hotel.py --calibrate "<真实页面URL>"
```

看 `output/calibration.json` 里的 `class_hints`，按顺序调 `config/selectors.json` 对应字段的候选 CSS，再 `--limit 1` 验证。

价格字段务必用 `.room-price .sale`（成交价）/ `.delete`（划线原价）；**不要**用宽泛的 `[class*=price]`，会命中左侧价格筛选栏（`¥0 - ¥200`）。

## 排障

| 现象 | 处理 |
| --- | --- |
| `no_browser_connected` | 扩展断线，请用户打开浏览器扩展等重连 |
| `daemon is running` 相关报错 | 让 `bsk` 自行拉起 daemon；受限环境用 `BSK_AUTO_START=0 bsk daemon start --foreground` 常驻 |
| 价格全空、状态 `needs_login` | 用户没登录，请其登录后重跑 |
| `retry_exhausted⟧ / 协作拒绝 | 页面风控 iframe 抖动；本技能已每家用独立会话 + 重试，仍失败就跳过该家并记 `error` |
| Excel 没生成 | 缺 `openpyxl`，`pip install openpyxl`；CSV/JSONL 不受影响 |

## 参考

- @references/data-schema.md — 每个字段的口径与来源
- @references/anti-detection.md — 拟人节奏设计、红线与理由
- @references/page-map.md — 实测的选择器与页面结构（改版时对照）
